#define _GNU_SOURCE
#include <gtk/gtk.h>
#include <gio/gio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <dirent.h>
#include <pwd.h>
#include <grp.h>
#include <errno.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <ctype.h>
#include <curl/curl.h>

typedef struct {
    GtkApplication *app;
    GtkWidget *win;
    GtkWidget *header;
    GtkWidget *dir_entry;
    GtkWidget *choose_btn;
    GtkWidget *refresh_btn;
    GtkWidget *build_btn;
    GtkWidget *stop_btn;
    GtkWidget *save_txt_btn;
    GtkWidget *save_pdf_btn;
    GtkWidget *notebook;

    /* Files tab */
    GtkWidget *files_view;
    GtkListStore *files_store;

    /* FS info tab */
    GtkWidget *fsinfo_view;

    /* Kernel config tab */
    GtkWidget *config_view;

    /* Build log tab */
    GtkWidget *build_view;

    /* Unifdef tab */
    GtkWidget *unifdef_url_entry;
    GtkWidget *unifdef_view;

    /* Build process */
    GSubprocess *proc;
    GInputStream *proc_out;
    GDataInputStream *proc_data;
    GCancellable *proc_cancel;
    gboolean build_running;

    gchar *current_dir;
} App;

enum {
    COL_NAME,
    COL_PATH,
    COL_SIZE,
    COL_MODE,
    COL_UID,
    COL_GID,
    COL_INODE,
    COL_NLINK,
    COL_MTIME,
    N_COLS
};

/* Utility: humanize sizes */
static void human_size(guint64 v, char *out, size_t outlen) {
    const char *units[] = {"B","KiB","MiB","GiB","TiB"};
    int i = 0;
    double d = (double)v;
    while (d >= 1024.0 && i < 4) { d /= 1024.0; i++; }
    snprintf(out, outlen, (d < 10.0 && i>0) ? "%.1f %s" : "%.0f %s", d, units[i]);
}

/* Utility: format mode like -rwxr-xr-x */
static void mode_string(mode_t m, char *s) {
    const char t = S_ISDIR(m)?'d':S_ISLNK(m)?'l':S_ISCHR(m)?'c':S_ISBLK(m)?'b':S_ISSOCK(m)?'s':S_ISFIFO(m)?'p':'-';
    s[0]=t;
    const char r[]="rwx";
    for(int i=0;i<9;i++){
        s[i+1] = (m & (1<<(8-i))) ? r[i%3] : '-';
    }
    /* setuid/setgid/sticky */
    if (m & S_ISUID) s[3]= (s[3]=='x'?'s':'S');
    if (m & S_ISGID) s[6]= (s[6]=='x'?'s':'S');
    if (m & S_ISVTX) s[9]= (s[9]=='x'?'t':'T');
    s[10]='\0';
}

/* Utility: append text to a GtkTextView */
static void textview_append(GtkWidget *tv, const char *text) {
    GtkTextBuffer *buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(tv));
    GtkTextIter end; gtk_text_buffer_get_end_iter(buf, &end);
    gtk_text_buffer_insert(buf, &end, text, -1);
}

/* Utility: set whole text of a GtkTextView */
static void textview_set(GtkWidget *tv, const char *text) {
    GtkTextBuffer *buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(tv));
    gtk_text_buffer_set_text(buf, text ? text : "", -1);
}

/* Strip HTML tags (simple, non-robust) */
static char *strip_html(const char *in) {
    if (!in) return g_strdup("");
    GString *out = g_string_new(NULL);
    gboolean in_tag = FALSE;
    for (const char *p=in; *p; p++){
        if (*p=='<') { in_tag=TRUE; continue; }
        if (*p=='>') { in_tag=FALSE; continue; }
        if (!in_tag) g_string_append_c(out, (*p=='\r')?'\n':*p);
    }
    /* Collapse some repeated newlines */
    char *s = out->str;
    GString *collapsed = g_string_new(NULL);
    int nl = 0;
    for (char *q=s; *q; q++){
        if (*q=='\n') { nl++; if (nl<=2) g_string_append_c(collapsed, '\n'); }
        else { nl=0; g_string_append_c(collapsed, *q); }
    }
    g_string_free(out, TRUE);
    return g_string_free(collapsed, FALSE);
}

/* libcurl write callback */
struct memchunk { char *data; size_t len; };
static size_t curl_write_cb(char *ptr, size_t size, size_t nmemb, void *userdata){
    size_t total = size*nmemb;
    struct memchunk *m = (struct memchunk*)userdata;
    char *newp = realloc(m->data, m->len + total + 1);
    if(!newp) return 0;
    m->data = newp;
    memcpy(m->data + m->len, ptr, total);
    m->len += total;
    m->data[m->len] = '\0';
    return total;
}

/* Fetch URL to string using libcurl */
static char *http_fetch(const char *url, char **err) {
    *err = NULL;
    CURL *curl = curl_easy_init();
    if(!curl){ *err=g_strdup("curl_easy_init failed"); return NULL; }
    struct memchunk m = {0};
    curl_easy_setopt(curl, CURLOPT_URL, url);
    curl_easy_setopt(curl, CURLOPT_USERAGENT, "kernel_gui/1.0");
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_write_cb);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &m);
    CURLcode rc = curl_easy_perform(curl);
    if (rc!=CURLE_OK) {
        *err = g_strdup(curl_easy_strerror(rc));
        curl_easy_cleanup(curl);
        free(m.data);
        return NULL;
    }
    long code=0; curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &code);
    curl_easy_cleanup(curl);
    if (code>=400) {
        *err = g_strdup_printf("HTTP %ld", code);
        free(m.data);
        return NULL;
    }
    return m.data; /* ownership transferred */
}

/* Populate file list */
static void populate_files(App *a, const char *dir) {
    gtk_list_store_clear(a->files_store);
    if (!dir || !g_file_test(dir, G_FILE_TEST_IS_DIR)) return;

    DIR *d = opendir(dir);
    if (!d) return;

    struct dirent *ent;
    while ((ent = readdir(d))) {
        if (g_strcmp0(ent->d_name,".")==0 || g_strcmp0(ent->d_name,"..")==0) continue;

        gchar *path = g_build_filename(dir, ent->d_name, NULL);
        struct stat st; if (lstat(path, &st)!=0) { g_free(path); continue; }

        char modes[11]; mode_string(st.st_mode, modes);
        char size_h[64]; human_size((guint64)st.st_size, size_h, sizeof size_h);

        struct passwd *pw = getpwuid(st.st_uid);
        struct group  *gr = getgrgid(st.st_gid);
        char owner[128]; snprintf(owner, sizeof owner, "%s(%u)", pw?pw->pw_name:"?", st.st_uid);
        char group[128]; snprintf(group, sizeof group, "%s(%u)", gr?gr->gr_name:"?", st.st_gid);

        char mtime[64]; struct tm tm; localtime_r(&st.st_mtime, &tm);
        strftime(mtime, sizeof mtime, "%Y-%m-%d %H:%M:%S", &tm);

        GtkTreeIter it;
        gtk_list_store_append(a->files_store, &it);
        gtk_list_store_set(a->files_store, &it,
            COL_NAME, ent->d_name,
            COL_PATH, path,
            COL_SIZE, size_h,
            COL_MODE, modes,
            COL_UID, owner,
            COL_GID, group,
            COL_INODE, (guint64)st.st_ino,
            COL_NLINK, (guint)st.st_nlink,
            COL_MTIME, mtime,
            -1);
        g_free(path);
    }
    closedir(d);
}

/* Load filesystem stats into fsinfo_view */
static void load_fsinfo(App *a, const char *dir) {
    if (!dir) { textview_set(a->fsinfo_view, "No directory selected.\n"); return; }
    struct statvfs vfs;
    if (statvfs(dir, &vfs)!=0) {
        textview_set(a->fsinfo_view, "statvfs failed.\n");
        return;
    }
    char buf[1024];
    char b_total[64], b_free[64], b_avail[64], f_files[64], f_ffree[64];
    human_size((guint64)vfs.f_frsize * vfs.f_blocks, b_total, sizeof b_total);
    human_size((guint64)vfs.f_frsize * vfs.f_bfree,  b_free,  sizeof b_free);
    human_size((guint64)vfs.f_frsize * vfs.f_bavail, b_avail, sizeof b_avail);
    snprintf(f_files, sizeof f_files, "%llu", (unsigned long long)vfs.f_files);
    snprintf(f_ffree, sizeof f_ffree, "%llu", (unsigned long long)vfs.f_ffree);

    snprintf(buf, sizeof buf,
        "Directory: %s\n"
        "Block size: %lu\n"
        "Total space: %s\n"
        "Free space:  %s\n"
        "Avail space: %s\n"
        "Total inodes: %s\n"
        "Free inodes:  %s\n",
        dir,
        (unsigned long)vfs.f_frsize,
        b_total, b_free, b_avail, f_files, f_ffree);
    textview_set(a->fsinfo_view, buf);
}

/* Load kernel .config if present */
static void load_config(App *a, const char *dir) {
    if (!dir) { textview_set(a->config_view, "No directory selected.\n"); return; }
    gchar *path = g_build_filename(dir, ".config", NULL);
    if (!g_file_test(path, G_FILE_TEST_IS_REGULAR)) {
        gchar *msg = g_strdup_printf("No .config found in %s\n", dir);
        textview_set(a->config_view, msg);
        g_free(msg);
        g_free(path);
        return;
    }
    gchar *contents = NULL; gsize len=0; GError *e=NULL;
    if (!g_file_get_contents(path, &contents, &len, &e)) {
        gchar *msg = g_strdup_printf("Failed to read %s: %s\n", path, e?e->message:"error");
        textview_set(a->config_view, msg);
        g_clear_error(&e);
        g_free(msg);
    } else {
        textview_set(a->config_view, contents);
    }
    g_free(contents);
    g_free(path);
}

/* Async build output handler */
static gboolean read_build_output(gpointer user);
static void start_build(App *a) {
    if (a->build_running || !a->current_dir) return;

    /* Determine jobs from env or default */
    const char *jobs_env = g_getenv("KERNEL_GUI_JOBS");
    int jobs = jobs_env ? MAX(1, atoi(jobs_env)) : (int)CLAMP((gint)g_get_num_processors(),1,64);

    /* Command: make -jN V=1 */
    gchar *jobs_str = g_strdup_printf("-j%d", jobs);
    const char *argvv[] = { "make", jobs_str, "V=1", NULL };

    GError *e=NULL;
    a->proc = g_subprocess_new(G_SUBPROCESS_FLAGS_STDOUT_PIPE | G_SUBPROCESS_FLAGS_STDERR_MERGE | G_SUBPROCESS_FLAGS_INHERIT_FDS,
                               &e, "make", jobs_str, "V=1", "-C", a->current_dir, NULL);
    g_free(jobs_str);

    textview_set(a->build_view, "");
    textview_append(a->build_view, "Starting build...\n");

    if (!a->proc) {
        textview_append(a->build_view, e?e->message:"Failed to start process.\n");
        g_clear_error(&e);
        return;
    }
    a->proc_out  = g_subprocess_get_stdout_pipe(a->proc);
    a->proc_data = g_data_input_stream_new(a->proc_out);
    a->proc_cancel = g_cancellable_new();
    a->build_running = TRUE;

    /* Periodically read lines */
    g_timeout_add(50, read_build_output, a);
}

static gboolean read_build_output(gpointer user) {
    App *a = (App*)user;
    if (!a->build_running || !a->proc_data) return G_SOURCE_REMOVE;
    GError *e=NULL;
    gsize len=0;
    char *line = g_data_input_stream_read_line(G_DATA_INPUT_STREAM(a->proc_data), &len, a->proc_cancel, &e);
    if (line) {
        textview_append(a->build_view, line);
        textview_append(a->build_view, "\n");
        g_free(line);
        return G_SOURCE_CONTINUE;
    }
    if (e && !g_error_matches(e, G_IO_ERROR, G_IO_ERROR_CANCELLED)) {
        textview_append(a->build_view, "\n[read error]\n");
        g_clear_error(&e);
    }

    /* Check if process exited */
    if (g_subprocess_wait_check(a->proc, NULL, NULL)) {
        textview_append(a->build_view, "\nBuild finished successfully.\n");
    } else {
        int ec = g_subprocess_get_exit_status(a->proc);
        gchar *msg = g_strdup_printf("\nBuild exited with status %d.\n", ec);
        textview_append(a->build_view, msg);
        g_free(msg);
    }
    a->build_running = FALSE;
    g_clear_object(&a->proc_data);
    g_clear_object(&a->proc_out);
    g_clear_object(&a->proc);
    g_clear_object(&a->proc_cancel);
    return G_SOURCE_REMOVE;
}

static void stop_build(App *a) {
    if (!a->build_running) return;
    g_cancellable_cancel(a->proc_cancel);
    g_subprocess_force_exit(a->proc);
    textview_append(a->build_view, "\nBuild stopped.\n");
}

/* Save current tab to text file */
static void save_current_tab_text(App *a) {
    GtkWidget *cur = NULL;
    int page = gtk_notebook_get_current_page(GTK_NOTEBOOK(a->notebook));
    cur = gtk_notebook_get_nth_page(GTK_NOTEBOOK(a->notebook), page);

    GtkWidget *tv = NULL;
    if (cur == gtk_widget_get_parent(a->files_view)) {
        /* Export the file list as TSV text */
        GString *s = g_string_new("NAME\tPATH\tSIZE\tMODE\tUID\tGID\tINODE\tNLINK\tMTIME\n");
        GtkTreeIter it;
        gboolean valid = gtk_tree_model_get_iter_first(GTK_TREE_MODEL(a->files_store), &it);
        while (valid) {
            gchar *name,*path,*size,*mode,*uid,*gid,*mtime;
            guint nlink;
            guint64 inode;
            gtk_tree_model_get(GTK_TREE_MODEL(a->files_store), &it,
                               COL_NAME,&name,COL_PATH,&path,COL_SIZE,&size,COL_MODE,&mode,
                               COL_UID,&uid,COL_GID,&gid,COL_INODE,&inode,COL_NLINK,&nlink,COL_MTIME,&mtime,-1);
            g_string_append_printf(s, "%s\t%s\t%s\t%s\t%s\t%s\t%llu\t%u\t%s\n",
                name,path,size,mode,uid,gid,(unsigned long long)inode,nlink,mtime);
            g_free(name); g_free(path); g_free(size); g_free(mode); g_free(uid); g_free(gid); g_free(mtime);
            valid = gtk_tree_model_iter_next(GTK_TREE_MODEL(a->files_store), &it);
        }
        GtkWidget *dlg = gtk_file_chooser_dialog_new("Save File List",
                            GTK_WINDOW(a->win), GTK_FILE_CHOOSER_ACTION_SAVE,
                            "_Cancel", GTK_RESPONSE_CANCEL, "_Save", GTK_RESPONSE_ACCEPT, NULL);
        gtk_file_chooser_set_current_name(GTK_FILE_CHOOSER(dlg), "file_list.txt");
        if (gtk_dialog_run(GTK_DIALOG(dlg))==GTK_RESPONSE_ACCEPT) {
            char *filename = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(dlg));
            g_file_set_contents(filename, s->str, s->len, NULL);
            g_free(filename);
        }
        gtk_widget_destroy(dlg);
        g_string_free(s, TRUE);
        return;
    } else if (cur == gtk_widget_get_parent(a->fsinfo_view)) {
        tv = a->fsinfo_view;
    } else if (cur == gtk_widget_get_parent(a->config_view)) {
        tv = a->config_view;
    } else if (cur == gtk_widget_get_parent(a->build_view)) {
        tv = a->build_view;
    } else if (cur == gtk_widget_get_parent(a->unifdef_view)) {
        tv = a->unifdef_view;
    }

    if (!tv) return;

    GtkTextBuffer *buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(tv));
    GtkTextIter start, end; gtk_text_buffer_get_bounds(buf, &start, &end);
    char *text = gtk_text_buffer_get_text(buf, &start, &end, FALSE);

    GtkWidget *dlg = gtk_file_chooser_dialog_new("Save Text",
                        GTK_WINDOW(a->win), GTK_FILE_CHOOSER_ACTION_SAVE,
                        "_Cancel", GTK_RESPONSE_CANCEL, "_Save", GTK_RESPONSE_ACCEPT, NULL);
    gtk_file_chooser_set_current_name(GTK_FILE_CHOOSER(dlg), "output.txt");
    if (gtk_dialog_run(GTK_DIALOG(dlg))==GTK_RESPONSE_ACCEPT) {
        char *filename = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(dlg));
        g_file_set_contents(filename, text, strlen(text), NULL);
        g_free(filename);
    }
    gtk_widget_destroy(dlg);
    g_free(text);
}

/* Export current text view to PDF using GtkPrintOperation (Print to File) */
static void print_draw_page(GtkPrintOperation *op, GtkPrintContext *ctx, int page_nr, gpointer user_data) {
    const char *text = (const char*)user_data;
    cairo_t *cr = gtk_print_context_get_cairo_context(ctx);
    PangoLayout *layout = gtk_print_context_create_pango_layout(ctx);
    PangoFontDescription *desc = pango_font_description_from_string("Monospace 9");
    pango_layout_set_font_description(layout, desc);
    pango_layout_set_width(layout, gtk_print_context_get_width(ctx) * PANGO_SCALE);
    pango_layout_set_text(layout, text, -1);
    int text_height;
    pango_layout_get_size(layout, NULL, &text_height);
    cairo_move_to(cr, 0, 0);
    pango_cairo_show_layout(cr, layout);
    g_object_unref(layout);
    pango_font_description_free(desc);
}
static void export_pdf_current(App *a) {
    /* Only for text-based tabs */
    GtkWidget *cur = gtk_notebook_get_nth_page(GTK_NOTEBOOK(a->notebook),
                                               gtk_notebook_get_current_page(GTK_NOTEBOOK(a->notebook)));
    GtkWidget *tv = NULL;
    if (cur == gtk_widget_get_parent(a->fsinfo_view)) tv = a->fsinfo_view;
    else if (cur == gtk_widget_get_parent(a->config_view)) tv = a->config_view;
    else if (cur == gtk_widget_get_parent(a->build_view)) tv = a->build_view;
    else if (cur == gtk_widget_get_parent(a->unifdef_view)) tv = a->unifdef_view;
    else {
        GtkWidget *msg = gtk_message_dialog_new(GTK_WINDOW(a->win), GTK_DIALOG_MODAL, GTK_MESSAGE_INFO, GTK_BUTTONS_OK,
                                                "Switch to a text tab (FS info, Config, Build, or Unifdef) to export PDF.");
        gtk_dialog_run(GTK_DIALOG(msg)); gtk_widget_destroy(msg);
        return;
    }
    GtkTextBuffer *buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(tv));
    GtkTextIter start, end; gtk_text_buffer_get_bounds(buf, &start, &end);
    char *text = gtk_text_buffer_get_text(buf, &start, &end, FALSE);

    GtkWidget *dlg = gtk_file_chooser_dialog_new("Export to PDF",
                        GTK_WINDOW(a->win), GTK_FILE_CHOOSER_ACTION_SAVE,
                        "_Cancel", GTK_RESPONSE_CANCEL, "_Export", GTK_RESPONSE_ACCEPT, NULL);
    gtk_file_chooser_set_current_name(GTK_FILE_CHOOSER(dlg), "output.pdf");
    if (gtk_dialog_run(GTK_DIALOG(dlg))==GTK_RESPONSE_ACCEPT) {
        char *filename = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(dlg));
        GtkPrintOperation *op = gtk_print_operation_new();
        gtk_print_operation_set_export_filename(op, filename);
        g_signal_connect(op, "draw-page", G_CALLBACK(print_draw_page), text);
        gtk_print_operation_run(op, GTK_PRINT_OPERATION_ACTION_EXPORT, GTK_WINDOW(a->win), NULL);
        g_object_unref(op);
        g_free(filename);
    }
    gtk_widget_destroy(dlg);
    g_free(text);
}

/* Handlers */
static void on_choose_dir(GtkButton *b, gpointer user_data) {
    App *a = (App*)user_data;
    GtkWidget *dlg = gtk_file_chooser_dialog_new("Select kernel source directory",
                        GTK_WINDOW(a->win), GTK_FILE_CHOOSER_ACTION_SELECT_FOLDER,
                        "_Cancel", GTK_RESPONSE_CANCEL, "_Open", GTK_RESPONSE_ACCEPT, NULL);
    if (gtk_dialog_run(GTK_DIALOG(dlg))==GTK_RESPONSE_ACCEPT) {
        char *dir = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(dlg));
        gtk_entry_set_text(GTK_ENTRY(a->dir_entry), dir);
        g_free(a->current_dir);
        a->current_dir = g_strdup(dir);
        g_free(dir);
        populate_files(a, a->current_dir);
        load_fsinfo(a, a->current_dir);
        load_config(a, a->current_dir);
    }
    gtk_widget_destroy(dlg);
}
static void on_refresh(GtkButton *b, gpointer user_data) {
    App *a = (App*)user_data;
    g_free(a->current_dir);
    a->current_dir = g_strdup(gtk_entry_get_text(GTK_ENTRY(a->dir_entry)));
    populate_files(a, a->current_dir);
    load_fsinfo(a, a->current_dir);
    load_config(a, a->current_dir);
}
static void on_build(GtkButton *b, gpointer user_data) {
    App *a = (App*)user_data;
    if (!a->current_dir || !g_file_test(a->current_dir, G_FILE_TEST_IS_DIR)) {
        GtkWidget *m = gtk_message_dialog_new(GTK_WINDOW(a->win), GTK_DIALOG_MODAL, GTK_MESSAGE_WARNING, GTK_BUTTONS_OK,
                                              "Select a valid kernel source directory first.");
        gtk_dialog_run(GTK_DIALOG(m)); gtk_widget_destroy(m);
        return;
    }
    start_build(a);
    gtk_notebook_set_current_page(GTK_NOTEBOOK(a->notebook), 3); /* Build tab */
}
static void on_stop(GtkButton *b, gpointer user_data) {
    stop_build((App*)user_data);
}
static void on_save_txt(GtkButton *b, gpointer user_data) {
    save_current_tab_text((App*)user_data);
}
static void on_save_pdf(GtkButton *b, gpointer user_data) {
    export_pdf_current((App*)user_data);
}
static void on_fetch_unifdef(GtkButton *b, gpointer user_data) {
    App *a = (App*)user_data;
    const char *url = gtk_entry_get_text(GTK_ENTRY(a->unifdef_url_entry));
    if (!url || !*url) url = "https://dotat.at/prog/unifdef/";
    char *err=NULL;
    textview_set(a->unifdef_view, "Fetching...\n");
    char *html = http_fetch(url, &err);
    if (!html) {
        gchar *msg = g_strdup_printf("Fetch error: %s\n", err?err:"unknown");
        textview_set(a->unifdef_view, msg);
        g_free(msg); g_free(err);
        return;
    }
    char *txt = strip_html(html);
    textview_set(a->unifdef_view, txt);
    g_free(txt); free(html);
}

/* UI setup helpers */
static GtkWidget* make_scrolled(GtkWidget *child) {
    GtkWidget *sw = gtk_scrolled_window_new(NULL, NULL);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(sw), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    gtk_container_add(GTK_CONTAINER(sw), child);
    return sw;
}
static GtkWidget* make_textview_mono(void) {
    GtkWidget *tv = gtk_text_view_new();
    PangoFontDescription *desc = pango_font_description_from_string("Monospace 10");
    gtk_widget_override_font(tv, desc);
    pango_font_description_free(desc);
    gtk_text_view_set_editable(GTK_TEXT_VIEW(tv), FALSE);
    gtk_text_view_set_wrap_mode(GTK_TEXT_VIEW(tv), GTK_WRAP_WORD_CHAR);
    return tv;
}
static GtkWidget* build_files_tab(App *a) {
    a->files_store = gtk_list_store_new(N_COLS,
        G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,
        G_TYPE_STRING, G_TYPE_STRING, G_TYPE_UINT64, G_TYPE_UINT, G_TYPE_STRING);
    a->files_view = gtk_tree_view_new_with_model(GTK_TREE_MODEL(a->files_store));
    const char *titles[] = {"Name","Path","Size","Mode","Owner","Group","Inode","Nlink","MTime"};
    int cols[] = {COL_NAME,COL_PATH,COL_SIZE,COL_MODE,COL_UID,COL_GID,COL_INODE,COL_NLINK,COL_MTIME};
    for (int i=0;i<9;i++){
        GtkCellRenderer *r = gtk_cell_renderer_text_new();
        GtkTreeViewColumn *c = gtk_tree_view_column_new_with_attributes(titles[i], r, "text", cols[i], NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(a->files_view), c);
    }
    return make_scrolled(a->files_view);
}
static GtkWidget* build_fsinfo_tab(App *a) {
    a->fsinfo_view = make_textview_mono();
    return make_scrolled(a->fsinfo_view);
}
static GtkWidget* build_config_tab(App *a) {
    a->config_view = make_textview_mono();
    return make_scrolled(a->config_view);
}
static GtkWidget* build_build_tab(App *a) {
    a->build_view = make_textview_mono();
    return make_scrolled(a->build_view);
}
static GtkWidget* build_unifdef_tab(App *a) {
    GtkWidget *box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 6);
    GtkWidget *row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 6);
    a->unifdef_url_entry = gtk_entry_new();
    gtk_entry_set_text(GTK_ENTRY(a->unifdef_url_entry), "https://dotat.at/prog/unifdef/");
    GtkWidget *btn = gtk_button_new_from_icon_name("web-browser", GTK_ICON_SIZE_BUTTON);
    gtk_widget_set_tooltip_text(btn, "Fetch URL");
    g_signal_connect(btn, "clicked", G_CALLBACK(on_fetch_unifdef), a);
    gtk_box_pack_start(GTK_BOX(row), gtk_label_new("URL:"), FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(row), a->unifdef_url_entry, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(row), btn, FALSE, FALSE, 0);
    a->unifdef_view = make_textview_mono();
    gtk_box_pack_start(GTK_BOX(box), row, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(box), make_scrolled(a->unifdef_view), TRUE, TRUE, 0);
    return box;
}

static void build_ui(App *a) {
    a->win = gtk_application_window_new(a->app);
    gtk_window_set_default_size(GTK_WINDOW(a->win), 1100, 700);
    gtk_window_set_title(GTK_WINDOW(a->win), "Kernel Source Explorer & Builder");
    gtk_window_set_icon_name(GTK_WINDOW(a->win), "computer");

    a->header = gtk_header_bar_new();
    gtk_header_bar_set_show_close_button(GTK_HEADER_BAR(a->header), TRUE);
    gtk_header_bar_set_title(GTK_HEADER_BAR(a->header), "Kernel Source Explorer");
    gtk_window_set_titlebar(GTK_WINDOW(a->win), a->header);

    GtkWidget *top = gtk_box_new(GTK_ORIENTATION_VERTICAL, 6);
    gtk_container_add(GTK_CONTAINER(a->win), top);

    /* Directory row */
    GtkWidget *row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 6);
    a->dir_entry = gtk_entry_new();
    gtk_entry_set_placeholder_text(GTK_ENTRY(a->dir_entry), "/path/to/linux-kernel");
    a->choose_btn = gtk_button_new_from_icon_name("folder-open", GTK_ICON_SIZE_BUTTON);
    a->refresh_btn = gtk_button_new_from_icon_name("view-refresh", GTK_ICON_SIZE_BUTTON);
    a->build_btn = gtk_button_new_from_icon_name("system-run", GTK_ICON_SIZE_BUTTON);
    a->stop_btn  = gtk_button_new_from_icon_name("media-playback-stop", GTK_ICON_SIZE_BUTTON);
    a->save_txt_btn = gtk_button_new_from_icon_name("document-save", GTK_ICON_SIZE_BUTTON);
    a->save_pdf_btn = gtk_button_new_from_icon_name("document-print", GTK_ICON_SIZE_BUTTON);
    gtk_widget_set_tooltip_text(a->build_btn, "Build (make -jN V=1)");
    gtk_widget_set_tooltip_text(a->stop_btn, "Stop build");
    gtk_widget_set_tooltip_text(a->save_txt_btn, "Save current tab to text");
    gtk_widget_set_tooltip_text(a->save_pdf_btn, "Export current tab to PDF");

    g_signal_connect(a->choose_btn, "clicked", G_CALLBACK(on_choose_dir), a);
    g_signal_connect(a->refresh_btn, "clicked", G_CALLBACK(on_refresh), a);
    g_signal_connect(a->build_btn, "clicked",  G_CALLBACK(on_build), a);
    g_signal_connect(a->stop_btn,  "clicked",  G_CALLBACK(on_stop), a);
    g_signal_connect(a->save_txt_btn, "clicked", G_CALLBACK(on_save_txt), a);
    g_signal_connect(a->save_pdf_btn, "clicked", G_CALLBACK(on_save_pdf), a);

    gtk_box_pack_start(GTK_BOX(row), gtk_label_new("Kernel dir:"), FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(row), a->dir_entry, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(row), a->choose_btn, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(row), a->refresh_btn, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(row), a->build_btn, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(row), a->stop_btn,  FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(row), a->save_txt_btn, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(row), a->save_pdf_btn, FALSE, FALSE, 0);

    gtk_box_pack_start(GTK_BOX(top), row, FALSE, FALSE, 0);

    /* Notebook */
    a->notebook = gtk_notebook_new();
    gtk_box_pack_start(GTK_BOX(top), a->notebook, TRUE, TRUE, 0);

    GtkWidget *tab1 = build_files_tab(a);
    GtkWidget *tab2 = build_fsinfo_tab(a);
    GtkWidget *tab3 = build_config_tab(a);
    GtkWidget *tab4 = build_build_tab(a);
    GtkWidget *tab5 = build_unifdef_tab(a);

    gtk_notebook_append_page(GTK_NOTEBOOK(a->notebook), tab1, gtk_image_new_from_icon_name("folder", GTK_ICON_SIZE_MENU));
    gtk_notebook_append_page(GTK_NOTEBOOK(a->notebook), tab2, gtk_label_new("FS info"));
    gtk_notebook_append_page(GTK_NOTEBOOK(a->notebook), tab3, gtk_label_new("Kernel .config"));
    gtk_notebook_append_page(GTK_NOTEBOOK(a->notebook), tab4, gtk_label_new("Build log"));
    gtk_notebook_append_page(GTK_NOTEBOOK(a->notebook), tab5, gtk_label_new("unifdef info"));
}

/* Application lifecycle */
static void on_activate(GtkApplication *app, gpointer user_data) {
    App *a = g_new0(App, 1);
    a->app = app;
    build_ui(a);

    /* Default directory guess if present */
    const char *guesses[] = { "./linux", "/usr/src/linux", NULL };
    for (int i=0; guesses[i]; i++){
        if (g_file_test(guesses[i], G_FILE_TEST_IS_DIR)) {
            gtk_entry_set_text(GTK_ENTRY(a->dir_entry), guesses[i]);
            a->current_dir = g_strdup(guesses[i]);
            populate_files(a, a->current_dir);
            load_fsinfo(a, a->current_dir);
            load_config(a, a->current_dir);
            break;
        }
    }

    g_object_set_data_full(G_OBJECT(a->win), "app-state", a, (GDestroyNotify)g_free);
    gtk_widget_show_all(a->win);
}

int main(int argc, char **argv) {
    curl_global_init(CURL_GLOBAL_DEFAULT);
    GtkApplication *app = gtk_application_new("com.example.kernel_gui", G_APPLICATION_FLAGS_NONE);
    g_signal_connect(app, "activate", G_CALLBACK(on_activate), NULL);
    int status = g_application_run(G_APPLICATION(app), argc, argv);
    g_object_unref(app);
    curl_global_cleanup();
    return status;
}
